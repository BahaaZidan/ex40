import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-your-polls',
  templateUrl: './your-polls.component.html',
  styleUrls: ['./your-polls.component.css']
})
export class YourPollsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
