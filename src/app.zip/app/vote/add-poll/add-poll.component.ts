import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-poll',
  templateUrl: './add-poll.component.html',
  styleUrls: ['./add-poll.component.css']
})
export class AddPollComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
