import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-poll',
  templateUrl: './edit-poll.component.html',
  styleUrls: ['./edit-poll.component.css']
})
export class EditPollComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
