import { Component, OnInit } from '@angular/core';
import { Http, Response } from '@angular/http';

import { VoteService } from '../vote.service';
//import { HttpModule, Http, Response, RequestOptions, Headers } from '@angular/http';

interface Poll {
    name: string;
    link: string;
  }

@Component({
  selector: 'app-poll-list',
  templateUrl: './poll-list.component.html',
  styleUrls: ['./poll-list.component.css']
})

export class PollListComponent implements OnInit {
  
  polls: Array<Poll>;
  response: any = [];
  constructor(private voteService:VoteService) {
    this.polls = [
      {
        name: 'lolo',
        link: '/vote/signup'
      },
      {
        name: '7onkololo',
        link: './'
      },
      {
        name: 'lolo',
        link: './'
      },
      {
        name: 'lolo',
        link: './'
      }
    ];

  }

  ngOnInit() {
    this.voteService.getPolls()
      .subscribe(polls => {
        this.response = polls;
        console.log(this.response);
        console.log(polls);
      });
  }

}
